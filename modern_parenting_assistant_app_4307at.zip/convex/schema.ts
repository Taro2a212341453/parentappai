import { defineSchema, defineTable } from "convex/server";
import { v } from "convex/values";
import { authTables } from "@convex-dev/auth/server";

const applicationTables = {
  children: defineTable({
    userId: v.id("users"),
    name: v.string(),
    birthDate: v.string(),
    allergies: v.array(v.string()),
    notes: v.optional(v.string()),
    profilePhotoId: v.optional(v.id("_storage")),
    deviceId: v.optional(v.string()),
    batteryLevel: v.optional(v.number()),
    lastBatteryUpdate: v.optional(v.number()),
  }).index("by_user", ["userId"]),

  locations: defineTable({
    userId: v.id("users"),
    name: v.string(),
    address: v.optional(v.string()),
    type: v.string(),
    latitude: v.optional(v.number()),
    longitude: v.optional(v.number()),
    geofenceRadius: v.optional(v.number()), // in meters
    isGeofenceEnabled: v.optional(v.boolean()),
  }).index("by_user", ["userId"]),

  checkIns: defineTable({
    userId: v.id("users"),
    locationId: v.id("locations"),
    childId: v.optional(v.id("children")),
    timestamp: v.number(),
    type: v.optional(v.string()), // "manual", "geofence_enter", "geofence_exit"
    notes: v.optional(v.string()),
    latitude: v.optional(v.number()),
    longitude: v.optional(v.number()),
  })
    .index("by_location", ["locationId"])
    .index("by_user", ["userId"])
    .index("by_child", ["childId"])
    .index("by_user_and_date", ["userId", "timestamp"]),

  locationHistory: defineTable({
    userId: v.id("users"),
    childId: v.id("children"),
    latitude: v.number(),
    longitude: v.number(),
    timestamp: v.number(),
    address: v.optional(v.string()),
    accuracy: v.optional(v.number()),
  })
    .index("by_child", ["childId"])
    .index("by_child_and_date", ["childId", "timestamp"]),

  geofenceAlerts: defineTable({
    userId: v.id("users"),
    childId: v.id("children"),
    locationId: v.id("locations"),
    alertType: v.string(), // "enter", "exit"
    timestamp: v.number(),
    isRead: v.boolean(),
  })
    .index("by_user", ["userId"])
    .index("by_child", ["childId"])
    .index("by_user_unread", ["userId", "isRead"]),

  drivingReports: defineTable({
    userId: v.id("users"),
    childId: v.id("children"),
    tripStart: v.number(),
    tripEnd: v.number(),
    startLocation: v.string(),
    endLocation: v.string(),
    distance: v.number(), // in miles
    maxSpeed: v.number(),
    avgSpeed: v.number(),
    hardBraking: v.number(),
    rapidAcceleration: v.number(),
    phoneUsage: v.number(), // minutes
    score: v.number(), // 0-100
  })
    .index("by_child", ["childId"])
    .index("by_child_and_date", ["childId", "tripStart"]),

  tasks: defineTable({
    userId: v.id("users"),
    title: v.string(),
    description: v.optional(v.string()),
    dueDate: v.number(),
    completed: v.boolean(),
    childId: v.optional(v.id("children")),
    category: v.string(),
    priority: v.string(),
    recurring: v.optional(v.string()),
  })
    .index("by_user", ["userId"])
    .index("by_child", ["childId"])
    .index("by_user_and_date", ["userId", "dueDate"]),

  healthLogs: defineTable({
    userId: v.id("users"),
    childId: v.optional(v.id("children")),
    type: v.string(),
    value: v.optional(v.string()),
    description: v.optional(v.string()), // Legacy field
    notes: v.optional(v.string()),
    timestamp: v.number(),
  })
    .index("by_user", ["userId"])
    .index("by_child", ["childId"])
    .index("by_child_and_date", ["childId", "timestamp"]),

  chatHistory: defineTable({
    userId: v.id("users"),
    message: v.string(),
    response: v.string(),
    timestamp: v.number(),
  }).index("by_user", ["userId"]),
};

export default defineSchema({
  ...authTables,
  ...applicationTables,
});
