import { mutation, query } from "./_generated/server";
import { v } from "convex/values";
import { getAuthUserId } from "@convex-dev/auth/server";

export const create = mutation({
  args: {
    childId: v.id("children"),
    tripStart: v.number(),
    tripEnd: v.number(),
    startLocation: v.string(),
    endLocation: v.string(),
    distance: v.number(),
    maxSpeed: v.number(),
    avgSpeed: v.number(),
    hardBraking: v.number(),
    rapidAcceleration: v.number(),
    phoneUsage: v.number(),
  },
  handler: async (ctx, args) => {
    const userId = await getAuthUserId(ctx);
    if (!userId) throw new Error("Not authenticated");

    // Calculate driving score (0-100)
    let score = 100;
    
    // Deduct points for speeding (assuming speed limit of 35 mph average)
    if (args.maxSpeed > 45) score -= Math.min(20, (args.maxSpeed - 45) * 2);
    
    // Deduct points for hard braking
    score -= Math.min(15, args.hardBraking * 3);
    
    // Deduct points for rapid acceleration
    score -= Math.min(15, args.rapidAcceleration * 3);
    
    // Deduct points for phone usage
    score -= Math.min(30, args.phoneUsage * 5);
    
    score = Math.max(0, score);

    return await ctx.db.insert("drivingReports", {
      userId,
      ...args,
      score,
    });
  },
});

export const list = query({
  args: {
    childId: v.optional(v.id("children")),
    startDate: v.optional(v.number()),
    endDate: v.optional(v.number()),
  },
  handler: async (ctx, args) => {
    const userId = await getAuthUserId(ctx);
    if (!userId) return [];

    let reports;
    
    if (args.childId) {
      reports = await ctx.db
        .query("drivingReports")
        .withIndex("by_child", (q) => q.eq("childId", args.childId!))
        .order("desc")
        .take(50);
    } else {
      reports = await ctx.db
        .query("drivingReports")
        .order("desc")
        .take(50);
    }

    // Filter by date range if provided
    if (args.startDate || args.endDate) {
      return reports.filter(report => {
        if (args.startDate && report.tripStart < args.startDate) return false;
        if (args.endDate && report.tripStart > args.endDate) return false;
        return true;
      });
    }

    return reports;
  },
});

export const getWeeklySummary = query({
  args: { childId: v.id("children") },
  handler: async (ctx, args) => {
    const userId = await getAuthUserId(ctx);
    if (!userId) return null;

    const weekAgo = Date.now() - 7 * 24 * 60 * 60 * 1000;
    
    const reports = await ctx.db
      .query("drivingReports")
      .withIndex("by_child_and_date", (q) => 
        q.eq("childId", args.childId).gte("tripStart", weekAgo)
      )
      .collect();

    if (reports.length === 0) return null;

    const totalDistance = reports.reduce((sum, r) => sum + r.distance, 0);
    const avgScore = reports.reduce((sum, r) => sum + r.score, 0) / reports.length;
    const totalHardBraking = reports.reduce((sum, r) => sum + r.hardBraking, 0);
    const totalRapidAcceleration = reports.reduce((sum, r) => sum + r.rapidAcceleration, 0);
    const totalPhoneUsage = reports.reduce((sum, r) => sum + r.phoneUsage, 0);
    const maxSpeed = Math.max(...reports.map(r => r.maxSpeed));

    return {
      totalTrips: reports.length,
      totalDistance: Math.round(totalDistance * 10) / 10,
      avgScore: Math.round(avgScore),
      totalHardBraking,
      totalRapidAcceleration,
      totalPhoneUsage,
      maxSpeed,
      weekStart: weekAgo,
    };
  },
});
