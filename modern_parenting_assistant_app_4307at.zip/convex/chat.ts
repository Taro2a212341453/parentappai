import { v } from "convex/values";
import { query, mutation, action } from "./_generated/server";
import { getAuthUserId } from "@convex-dev/auth/server";
import { api } from "./_generated/api";

export const getHistory = query({
  args: {},
  handler: async (ctx) => {
    const userId = await getAuthUserId(ctx);
    if (!userId) return [];

    return await ctx.db
      .query("chatHistory")
      .withIndex("by_user", (q) => q.eq("userId", userId))
      .order("asc")
      .collect();
  },
});

export const clearHistory = mutation({
  args: {},
  handler: async (ctx) => {
    const userId = await getAuthUserId(ctx);
    if (!userId) throw new Error("Not authenticated");

    const chatHistory = await ctx.db
      .query("chatHistory")
      .withIndex("by_user", (q) => q.eq("userId", userId))
      .collect();

    for (const chat of chatHistory) {
      await ctx.db.delete(chat._id);
    }
  },
});

export const sendMessage = action({
  args: { message: v.string() },
  handler: async (ctx, args) => {
    const userId = await getAuthUserId(ctx);
    if (!userId) throw new Error("Not authenticated");

    // Get user's children for context
    const children = await ctx.runQuery(api.children.list);
    
    try {
      // Generate a helpful response based on common parenting topics
      let aiResponse = generateParentingResponse(args.message, children);

      // Save to chat history
      await ctx.runMutation(api.chat.saveToHistory, {
        message: args.message,
        response: aiResponse,
      });

      return aiResponse;
    } catch (error) {
      console.error("Chat error:", error);
      return "I'm here to help with your parenting questions! Feel free to ask about child development, health, activities, or any concerns you might have. 💙";
    }
  },
});

function generateParentingResponse(message: string, children: any[]): string {
  const lowerMessage = message.toLowerCase();
  
  // Generate variety of tips based on different topics
  const tipVariations = {
    sleep: [
      `😴 Sleep Tips:\n\n• Establish a consistent bedtime routine\n• Create a calm, dark environment\n• Avoid screens 1 hour before bed\n• Consider age-appropriate sleep schedules\n• For toddlers: 11-14 hours total sleep\n• For school-age: 9-11 hours per night\n\nSweet dreams! 🌙`,
      `😴 Better Sleep Habits:\n\n• Start winding down 30 minutes before bed\n• Try a warm bath or gentle massage\n• Read a calming story together\n• Keep bedroom temperature cool (65-68°F)\n• Use white noise if helpful\n• Be patient - sleep changes take time\n\nConsistent routines work wonders! 🌙`,
      `😴 Sleep Solutions:\n\n• Morning sunlight helps set circadian rhythms\n• Limit caffeine and sugar in the afternoon\n• Create a cozy sleep environment\n• Try relaxation techniques like deep breathing\n• Address any fears or anxieties\n• Consider a comfort object\n\nGood sleep = better days for everyone! 🌙`
    ],
    nutrition: [
      `🍎 Nutrition Guidance:\n\n• Offer variety - different colors, textures, flavors\n• Make mealtimes positive and pressure-free\n• Include kids in meal planning and prep\n• Limit processed foods and sugary drinks\n• Model healthy eating habits\n• Stay patient - it can take 10+ exposures to new foods\n\nHealthy eating is a journey! 🥗`,
      `🍎 Feeding Success:\n\n• Serve new foods alongside familiar favorites\n• Let kids explore food with their hands\n• Avoid bribing with dessert\n• Focus on balanced meals over perfect eating\n• Stay hydrated with water throughout the day\n• Make snacks count with nutrients\n\nEvery bite is progress! 🥗`,
      `🍎 Mealtime Magic:\n\n• Eat together as a family when possible\n• Let kids help with age-appropriate cooking tasks\n• Try the "one bite rule" without pressure\n• Offer choices between healthy options\n• Keep mealtimes relaxed and fun\n• Trust your child's hunger cues\n\nBuilding lifelong healthy habits! 🥗`
    ],
    behavior: [
      `🎯 Positive Discipline Strategies:\n\n• Stay calm and consistent\n• Set clear, age-appropriate expectations\n• Use positive reinforcement for good behavior\n• Redirect rather than just say "no"\n• Natural consequences work better than punishment\n• Take breaks when you're feeling overwhelmed\n\nRemember: You're teaching, not punishing! 💪`,
      `🎯 Behavior Management:\n\n• Catch them being good and praise specifically\n• Create predictable routines and structure\n• Offer choices within acceptable limits\n• Use "when/then" statements instead of threats\n• Model the behavior you want to see\n• Address underlying needs (hunger, tiredness, etc.)\n\nConsistency is key to success! 💪`,
      `🎯 Gentle Guidance:\n\n• Connect before you correct\n• Use empathy to acknowledge feelings\n• Set boundaries with kindness but firmness\n• Focus on solutions together\n• Teach problem-solving skills\n• Remember that mistakes are learning opportunities\n\nBuilding character takes time and patience! 💪`
    ]
  };
  
  // Sleep-related questions
  if (lowerMessage.includes('sleep') || lowerMessage.includes('bedtime') || lowerMessage.includes('nap')) {
    const tips = tipVariations.sleep;
    return tips[Math.floor(Math.random() * tips.length)];
  }
  
  // Feeding/nutrition questions
  if (lowerMessage.includes('eat') || lowerMessage.includes('food') || lowerMessage.includes('meal') || lowerMessage.includes('nutrition')) {
    const tips = tipVariations.nutrition;
    return tips[Math.floor(Math.random() * tips.length)];
  }
  
  // Behavior and discipline
  if (lowerMessage.includes('behavior') || lowerMessage.includes('discipline') || lowerMessage.includes('tantrum') || lowerMessage.includes('misbehav')) {
    const tips = tipVariations.behavior;
    return tips[Math.floor(Math.random() * tips.length)];
  }
  
  // Development and milestones
  if (lowerMessage.includes('develop') || lowerMessage.includes('milestone') || lowerMessage.includes('learn') || lowerMessage.includes('skill')) {
    const developmentTips = [
      `🌱 Child Development Insights:\n\n• Every child develops at their own pace\n• Play is how children learn best\n• Read together daily for language development\n• Encourage independence with age-appropriate tasks\n• Celebrate small wins and progress\n• Trust your instincts - you know your child best\n\nIf you have specific concerns, consult your pediatrician! 📚`,
      `🌱 Growth & Learning:\n\n• Provide rich sensory experiences\n• Encourage curiosity and questions\n• Limit comparisons to other children\n• Focus on effort over achievement\n• Create opportunities for social interaction\n• Support their unique interests and strengths\n\nEvery child blooms in their own time! 📚`
    ];
    return developmentTips[Math.floor(Math.random() * developmentTips.length)];
  }
  
  // Health and safety
  if (lowerMessage.includes('sick') || lowerMessage.includes('fever') || lowerMessage.includes('health') || lowerMessage.includes('doctor')) {
    return `🏥 Health & Safety Reminders:\n\n• Trust your parental instincts\n• Keep a thermometer and basic first aid supplies handy\n• Know when to call the doctor vs. when to wait\n• Stay up to date on vaccinations\n• Childproof your home as they grow\n• Teach safety rules in age-appropriate ways\n\nWhen in doubt, contact your healthcare provider! 🩺`;
  }
  
  // Screen time and technology
  if (lowerMessage.includes('screen') || lowerMessage.includes('tv') || lowerMessage.includes('tablet') || lowerMessage.includes('phone')) {
    return `📱 Screen Time Guidelines:\n\n• Under 18 months: Avoid screens except video chatting\n• 18-24 months: Watch high-quality programming together\n• 2-5 years: Limit to 1 hour of high-quality content\n• 6+: Consistent limits that don't interfere with sleep/activity\n• Create tech-free zones (meals, bedrooms)\n• Model healthy screen habits yourself\n\nBalance is key! 🎮`;
  }
  
  // General parenting support
  if (lowerMessage.includes('stress') || lowerMessage.includes('overwhelm') || lowerMessage.includes('tired') || lowerMessage.includes('help')) {
    const supportTips = [
      `💙 Parenting Support:\n\n• You're doing better than you think!\n• It's okay to ask for help\n• Take care of yourself too - you matter\n• Connect with other parents for support\n• Remember that phases are temporary\n• Celebrate the small moments of joy\n\nParenting is hard, but you've got this! 🤗`,
      `💙 Self-Care Reminder:\n\n• Take breaks when you need them\n• Practice self-compassion\n• Find your support network\n• Remember your "why" for parenting\n• It's okay to have bad days\n• You don't have to be perfect\n\nYou're exactly the parent your child needs! 🤗`
    ];
    return supportTips[Math.floor(Math.random() * supportTips.length)];
  }
  
  // Default response with context about children
  let response = `Hi there! I'm here to help with all your parenting questions. `;
  
  if (children.length > 0) {
    response += `I see you have ${children.length} child${children.length > 1 ? 'ren' : ''}: `;
    response += children.map(child => `${child.name} (age ${child.age})`).join(", ");
    response += `. `;
  }
  
  response += `Feel free to ask me about:

🍼 Feeding & nutrition
😴 Sleep & bedtime routines  
🎯 Behavior & discipline
🌱 Development & milestones
🏥 Health & safety
📱 Screen time & technology
💙 General parenting support

What would you like to know more about?`;

  return response;
}

export const saveToHistory = mutation({
  args: {
    message: v.string(),
    response: v.string(),
  },
  handler: async (ctx, args) => {
    const userId = await getAuthUserId(ctx);
    if (!userId) throw new Error("Not authenticated");

    await ctx.db.insert("chatHistory", {
      userId,
      timestamp: Date.now(),
      ...args,
    });
  },
});
