import { mutation, query } from "./_generated/server";
import { v } from "convex/values";
import { getAuthUserId } from "@convex-dev/auth/server";

export const create = mutation({
  args: {
    name: v.string(),
    address: v.optional(v.string()),
    type: v.string(),
    latitude: v.optional(v.number()),
    longitude: v.optional(v.number()),
    geofenceRadius: v.optional(v.number()),
    isGeofenceEnabled: v.optional(v.boolean()),
  },
  handler: async (ctx, args) => {
    const userId = await getAuthUserId(ctx);
    if (!userId) throw new Error("Not authenticated");

    return await ctx.db.insert("locations", {
      userId,
      ...args,
    });
  },
});

export const list = query({
  args: {},
  handler: async (ctx) => {
    const userId = await getAuthUserId(ctx);
    if (!userId) return [];

    return await ctx.db
      .query("locations")
      .withIndex("by_user", (q) => q.eq("userId", userId))
      .collect();
  },
});

export const update = mutation({
  args: {
    locationId: v.id("locations"),
    name: v.optional(v.string()),
    address: v.optional(v.string()),
    type: v.optional(v.string()),
    latitude: v.optional(v.number()),
    longitude: v.optional(v.number()),
    geofenceRadius: v.optional(v.number()),
    isGeofenceEnabled: v.optional(v.boolean()),
  },
  handler: async (ctx, args) => {
    const userId = await getAuthUserId(ctx);
    if (!userId) throw new Error("Not authenticated");

    const { locationId, ...updates } = args;
    const location = await ctx.db.get(locationId);
    
    if (!location || location.userId !== userId) {
      throw new Error("Location not found or unauthorized");
    }

    return await ctx.db.patch(locationId, updates);
  },
});

export const checkIn = mutation({
  args: {
    locationId: v.id("locations"),
    childId: v.optional(v.id("children")),
    notes: v.optional(v.string()),
    type: v.optional(v.string()),
    latitude: v.optional(v.number()),
    longitude: v.optional(v.number()),
  },
  handler: async (ctx, args) => {
    const userId = await getAuthUserId(ctx);
    if (!userId) throw new Error("Not authenticated");

    return await ctx.db.insert("checkIns", {
      userId,
      locationId: args.locationId,
      childId: args.childId,
      timestamp: Date.now(),
      type: args.type || "manual",
      notes: args.notes,
      latitude: args.latitude,
      longitude: args.longitude,
    });
  },
});

export const getRecentCheckIns = query({
  args: { limit: v.optional(v.number()) },
  handler: async (ctx, args) => {
    const userId = await getAuthUserId(ctx);
    if (!userId) return [];

    const checkIns = await ctx.db
      .query("checkIns")
      .withIndex("by_user", (q) => q.eq("userId", userId))
      .order("desc")
      .take(args.limit || 10);

    const enrichedCheckIns = await Promise.all(
      checkIns.map(async (checkIn) => {
        const location = await ctx.db.get(checkIn.locationId);
        const child = checkIn.childId ? await ctx.db.get(checkIn.childId) : null;
        
        return {
          ...checkIn,
          locationName: location?.name || "Unknown Location",
          locationType: location?.type || "other",
          childName: child?.name,
        };
      })
    );

    return enrichedCheckIns;
  },
});

export const getLocationHistory = query({
  args: {
    childId: v.id("children"),
    startDate: v.optional(v.number()),
    endDate: v.optional(v.number()),
  },
  handler: async (ctx, args) => {
    const userId = await getAuthUserId(ctx);
    if (!userId) return [];

    const startDate = args.startDate || Date.now() - 7 * 24 * 60 * 60 * 1000; // 7 days ago
    const endDate = args.endDate || Date.now();

    return await ctx.db
      .query("locationHistory")
      .withIndex("by_child_and_date", (q) => 
        q.eq("childId", args.childId).gte("timestamp", startDate).lte("timestamp", endDate)
      )
      .order("desc")
      .take(100);
  },
});

export const addLocationHistory = mutation({
  args: {
    childId: v.id("children"),
    latitude: v.number(),
    longitude: v.number(),
    address: v.optional(v.string()),
    accuracy: v.optional(v.number()),
  },
  handler: async (ctx, args) => {
    const userId = await getAuthUserId(ctx);
    if (!userId) throw new Error("Not authenticated");

    return await ctx.db.insert("locationHistory", {
      userId,
      childId: args.childId,
      latitude: args.latitude,
      longitude: args.longitude,
      timestamp: Date.now(),
      address: args.address,
      accuracy: args.accuracy,
    });
  },
});

export const getGeofenceAlerts = query({
  args: { unreadOnly: v.optional(v.boolean()) },
  handler: async (ctx, args) => {
    const userId = await getAuthUserId(ctx);
    if (!userId) return [];

    let alertsQuery = ctx.db.query("geofenceAlerts").withIndex("by_user", (q) => q.eq("userId", userId));
    
    if (args.unreadOnly) {
      alertsQuery = ctx.db.query("geofenceAlerts").withIndex("by_user_unread", (q) => 
        q.eq("userId", userId).eq("isRead", false)
      );
    }

    const alerts = await alertsQuery.order("desc").take(50);

    const enrichedAlerts = await Promise.all(
      alerts.map(async (alert) => {
        const location = await ctx.db.get(alert.locationId);
        const child = await ctx.db.get(alert.childId);
        
        return {
          ...alert,
          locationName: location?.name || "Unknown Location",
          childName: child?.name || "Unknown Child",
        };
      })
    );

    return enrichedAlerts;
  },
});

export const markAlertAsRead = mutation({
  args: { alertId: v.id("geofenceAlerts") },
  handler: async (ctx, args) => {
    const userId = await getAuthUserId(ctx);
    if (!userId) throw new Error("Not authenticated");

    const alert = await ctx.db.get(args.alertId);
    if (!alert || alert.userId !== userId) {
      throw new Error("Alert not found or unauthorized");
    }

    return await ctx.db.patch(args.alertId, { isRead: true });
  },
});

export const updateBatteryLevel = mutation({
  args: {
    childId: v.id("children"),
    batteryLevel: v.number(),
  },
  handler: async (ctx, args) => {
    const userId = await getAuthUserId(ctx);
    if (!userId) throw new Error("Not authenticated");

    const child = await ctx.db.get(args.childId);
    if (!child || child.userId !== userId) {
      throw new Error("Child not found or unauthorized");
    }

    return await ctx.db.patch(args.childId, {
      batteryLevel: args.batteryLevel,
      lastBatteryUpdate: Date.now(),
    });
  },
});
