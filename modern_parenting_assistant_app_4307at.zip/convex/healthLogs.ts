import { v } from "convex/values";
import { query, mutation, action } from "./_generated/server";
import { getAuthUserId } from "@convex-dev/auth/server";
import { api } from "./_generated/api";

export const list = query({
  args: { childId: v.optional(v.id("children")) },
  handler: async (ctx, args) => {
    const userId = await getAuthUserId(ctx);
    if (!userId) return [];

    let logs;
    
    if (args.childId) {
      logs = await ctx.db.query("healthLogs").withIndex("by_child", (q) => q.eq("childId", args.childId!)).order("desc").take(50);
    } else {
      logs = await ctx.db.query("healthLogs").withIndex("by_user", (q) => q.eq("userId", userId)).order("desc").take(50);
    }

    return Promise.all(
      logs.map(async (log) => {
        const child = log.childId ? await ctx.db.get(log.childId) : null;
        return {
          ...log,
          childName: child?.name || "Unknown",
          value: log.value || log.description || "", // Handle legacy data
        };
      })
    );
  },
});

export const create = mutation({
  args: {
    childId: v.id("children"),
    type: v.string(),
    value: v.string(),
    notes: v.optional(v.string()),
  },
  handler: async (ctx, args) => {
    const userId = await getAuthUserId(ctx);
    if (!userId) throw new Error("Not authenticated");

    const child = await ctx.db.get(args.childId);
    if (!child || child.userId !== userId) {
      throw new Error("Child not found or unauthorized");
    }

    return await ctx.db.insert("healthLogs", {
      userId,
      timestamp: Date.now(),
      ...args,
    });
  },
});

export const remove = mutation({
  args: { id: v.id("healthLogs") },
  handler: async (ctx, args) => {
    const userId = await getAuthUserId(ctx);
    if (!userId) throw new Error("Not authenticated");

    const log = await ctx.db.get(args.id);
    if (!log || log.userId !== userId) {
      throw new Error("Log not found or unauthorized");
    }

    await ctx.db.delete(args.id);
  },
});

export const getWeeklySummary = query({
  args: { childId: v.id("children") },
  handler: async (ctx, args) => {
    const userId = await getAuthUserId(ctx);
    if (!userId) return null;

    const weekAgo = Date.now() - 7 * 24 * 60 * 60 * 1000;
    
    const logs = await ctx.db
      .query("healthLogs")
      .withIndex("by_child_and_date", (q) => 
        q.eq("childId", args.childId).gte("timestamp", weekAgo)
      )
      .collect();

    const summary = {
      totalEntries: logs.length,
      mealCount: logs.filter(l => l.type === "meal").length,
      sleepCount: logs.filter(l => l.type === "sleep").length,
      moodEntries: logs.filter(l => l.type === "mood"),
      symptomEntries: logs.filter(l => l.type === "symptom"),
    };

    return summary;
  },
});

export const validateEntry = action({
  args: { type: v.string(), value: v.string() },
  handler: async (ctx, args) => {
    try {
      const OpenAI = (await import("openai")).default;
      const openai = new OpenAI({
        baseURL: process.env.CONVEX_OPENAI_BASE_URL,
        apiKey: process.env.CONVEX_OPENAI_API_KEY,
      });

      const completion: any = await openai.chat.completions.create({
        model: "gpt-4.1-nano",
        messages: [
          { role: "system", content: "Validate health entries. Return 'valid' or suggest correction." },
          { role: "user", content: `Type: ${args.type}, Value: "${args.value}"` }
        ],
        max_tokens: 30,
      });

      const response = completion.choices[0]?.message?.content || "";
      return { isValid: response.includes("valid"), suggestion: response };
    } catch (error) {
      return { isValid: true, suggestion: null };
    }
  },
});
