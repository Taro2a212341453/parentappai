import { v } from "convex/values";
import { action } from "./_generated/server";
import { getAuthUserId } from "@convex-dev/auth/server";
import { api } from "./_generated/api";

export const generateTrendAnalysis = action({
  args: { childId: v.id("children") },
  handler: async (ctx, args): Promise<string> => {
    try {
      const logs: any[] = await ctx.runQuery(api.healthLogs.list, { childId: args.childId });
      const thirtyDaysAgo = Date.now() - 30 * 24 * 60 * 60 * 1000;
      const recentLogs: any[] = logs.filter((log: any) => log.timestamp > thirtyDaysAgo);

      if (recentLogs.length < 5) {
        return "Not enough data yet. Keep logging your child's health activities to see AI-powered insights! 📊✨";
      }

      const moodLogs = recentLogs.filter((l: any) => l.type === "mood");
      const sleepLogs = recentLogs.filter((l: any) => l.type === "sleep");
      const mealLogs = recentLogs.filter((l: any) => l.type === "meal");
      const symptomLogs = recentLogs.filter((l: any) => l.type === "symptom");

      // Generate analysis without external API
      let analysis = "Health Insights Summary\n\n";
      
      if (moodLogs.length > 0) {
        const recentMoods = moodLogs.slice(0, 5).map(m => m.value);
        analysis += `😊 Mood Patterns: Recent moods include ${recentMoods.join(", ")}. `;
        if (recentMoods.some(mood => mood.toLowerCase().includes('happy') || mood.toLowerCase().includes('good'))) {
          analysis += "Great to see positive emotions! ";
        }
        analysis += "\n\n";
      }

      if (sleepLogs.length > 0) {
        const avgSleep = sleepLogs.reduce((sum, log) => sum + parseFloat(log.value || "0"), 0) / sleepLogs.length;
        analysis += `😴 Sleep Patterns: Average sleep is ${avgSleep.toFixed(1)} hours. `;
        if (avgSleep >= 8) {
          analysis += "Excellent sleep habits! ";
        } else if (avgSleep >= 6) {
          analysis += "Consider aiming for more sleep for better health. ";
        }
        analysis += "\n\n";
      }

      if (mealLogs.length > 0) {
        analysis += `🍽️ Nutrition: ${mealLogs.length} meals logged recently. Keep tracking for better insights! `;
        analysis += "\n\n";
      }

      if (symptomLogs.length > 0) {
        analysis += `🤒 Health Notes: ${symptomLogs.length} symptoms tracked. Monitor patterns and consult healthcare providers if needed. `;
        analysis += "\n\n";
      }

      analysis += "💡 Tip: Continue logging daily activities to unlock more personalized insights!";

      return analysis;
    } catch (error) {
      console.error("Trend analysis error:", error);
      return "Unable to generate analysis at this time. Please try again later. 🔄";
    }
  },
});

export const validateHealthInput = action({
  args: {
    type: v.string(),
    value: v.string(),
  },
  handler: async (ctx, args): Promise<{ isValid: boolean; suggestion: string | null }> => {
    try {
      const value = args.value.toLowerCase().trim();
      
      // Strict content filtering - more comprehensive list
      const inappropriateWords = [
        // Violence and harm
        'hate', 'kill', 'die', 'death', 'suicide', 'hurt', 'pain', 'blood', 'violence', 'murder', 'stab', 'shoot', 'gun', 'knife', 'weapon',
        // Substances
        'drug', 'drugs', 'alcohol', 'beer', 'wine', 'drunk', 'high', 'weed', 'marijuana', 'cocaine', 'heroin', 'meth', 'pills', 'smoking', 'cigarette',
        // Sexual content
        'sex', 'sexual', 'porn', 'naked', 'nude', 'breast', 'penis', 'vagina', 'orgasm', 'masturbate',
        // Profanity and insults
        'fuck', 'shit', 'damn', 'hell', 'bitch', 'ass', 'bastard', 'crap', 'piss',
        'stupid', 'dumb', 'idiot', 'moron', 'loser', 'ugly', 'fat', 'skinny', 'retard',
        // Inappropriate behavior
        'abuse', 'inappropriate', 'touching', 'molest', 'rape', 'assault'
      ];
      
      // Check for inappropriate content
      const hasInappropriateContent = inappropriateWords.some(word => {
        // Check exact word match and common variations
        const regex = new RegExp(`\\b${word.replace(/[.*+?^${}()|[\]\\]/g, '\\$&')}\\b`, 'i');
        return regex.test(value) || value.includes(word.replace(/[aeiou]/g, '*'));
      });
      
      if (hasInappropriateContent) {
        return { 
          isValid: false, 
          suggestion: "Please use appropriate language when describing health information." 
        };
      }

      // Check for excessive length
      if (value.length > 500) {
        return {
          isValid: false,
          suggestion: "Please keep your entry shorter and more concise."
        };
      }

      // Check for minimum length
      if (value.length < 2) {
        return {
          isValid: false,
          suggestion: "Please provide more detail in your entry."
        };
      }
      
      switch (args.type) {
        case "mood":
          const validMoods = [
            'happy', 'sad', 'angry', 'excited', 'calm', 'anxious', 'tired', 'energetic', 
            'content', 'frustrated', 'joyful', 'worried', 'peaceful', 'cheerful', 'grumpy', 
            'playful', 'sleepy', 'cranky', 'giggly', 'upset', 'proud', 'shy', 'brave', 
            'silly', 'curious', 'bored', 'surprised', 'confused', 'relaxed', 'restless'
          ];
          const isValidMood = validMoods.some(mood => value.includes(mood)) || 
                             (value.length >= 3 && value.length <= 100 && /^[a-zA-Z\s,.-]+$/.test(value));
          return { 
            isValid: isValidMood, 
            suggestion: isValidMood ? null : "Please describe an emotion like 'happy', 'sad', 'excited', or 'calm'" 
          };
          
        case "meal":
          // Check for valid meal description
          const hasFood = /\b(eat|ate|food|meal|breakfast|lunch|dinner|snack|fruit|vegetable|meat|fish|chicken|rice|bread|pasta|cereal|milk|juice|water)\b/i.test(value);
          const isValidMeal = value.length >= 3 && value.length <= 300 && 
                             !value.match(/^[0-9]+$/) && 
                             (hasFood || value.split(' ').length >= 2);
          return { 
            isValid: isValidMeal, 
            suggestion: isValidMeal ? null : "Please describe the food or meal eaten (e.g., 'oatmeal with berries', 'chicken and rice')" 
          };
          
        case "symptom":
          const commonSymptoms = /\b(fever|cough|cold|runny nose|headache|stomach|tummy|ache|pain|sore|tired|sleepy|congested|sneezing|rash|itch)\b/i.test(value);
          const isValidSymptom = value.length >= 3 && value.length <= 200 && 
                                 (commonSymptoms || value.split(' ').length >= 2);
          return { 
            isValid: isValidSymptom, 
            suggestion: isValidSymptom ? null : "Please describe the symptom in more detail (e.g., 'mild fever', 'runny nose', 'headache')" 
          };
          
        case "medicine":
          const hasMedicine = /\b(tylenol|ibuprofen|advil|motrin|vitamin|medicine|medication|dose|ml|mg|tablet|liquid|drops|syrup)\b/i.test(value);
          const isValidMedicine = value.length >= 2 && value.length <= 150 && 
                                  (hasMedicine || value.split(' ').length >= 2);
          return { 
            isValid: isValidMedicine, 
            suggestion: isValidMedicine ? null : "Please specify the medication name and dosage (e.g., 'Tylenol 5ml', 'vitamin D')" 
          };
          
        default:
          return { isValid: true, suggestion: null };
      }
    } catch (error) {
      console.error("Validation error:", error);
      return { isValid: true, suggestion: null };
    }
  },
});

export const capitalizeAndCorrectText = action({
  args: { text: v.string() },
  handler: async (ctx, args): Promise<string> => {
    try {
      let text = args.text.trim();
      
      // Basic capitalization and grammar corrections
      text = text.toLowerCase();
      
      // Capitalize first letter of each sentence
      text = text.replace(/(^|\. )([a-z])/g, (match, p1, p2) => p1 + p2.toUpperCase());
      
      // Capitalize proper nouns and names
      const properNouns = ['monday', 'tuesday', 'wednesday', 'thursday', 'friday', 'saturday', 'sunday',
                           'january', 'february', 'march', 'april', 'may', 'june', 'july', 'august', 
                           'september', 'october', 'november', 'december', 'i', 'mom', 'dad', 'grandma', 
                           'grandpa', 'doctor', 'school', 'home'];
      
      properNouns.forEach(noun => {
        const regex = new RegExp(`\\b${noun}\\b`, 'gi');
        text = text.replace(regex, noun.charAt(0).toUpperCase() + noun.slice(1));
      });
      
      // Fix common grammar issues
      text = text.replace(/\bi\b/g, 'I');
      text = text.replace(/\bdont\b/g, "don't");
      text = text.replace(/\bcant\b/g, "can't");
      text = text.replace(/\bwont\b/g, "won't");
      text = text.replace(/\bisnt\b/g, "isn't");
      text = text.replace(/\barent\b/g, "aren't");
      text = text.replace(/\bwasnt\b/g, "wasn't");
      text = text.replace(/\bwerent\b/g, "weren't");
      text = text.replace(/\bhasnt\b/g, "hasn't");
      text = text.replace(/\bhavent\b/g, "haven't");
      text = text.replace(/\bdidnt\b/g, "didn't");
      text = text.replace(/\bdoesnt\b/g, "doesn't");
      
      return text;
    } catch (error) {
      console.error("Text correction error:", error);
      return args.text;
    }
  },
});
